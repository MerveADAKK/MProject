import RoutesComponent from './component/routes/RoutesComponent';

function App() {
  return (
    <div>
      <RoutesComponent />
    </div>
  );
}

export default App;
