package com.godoro.spring.orm.layer.data.entity;

public enum CartStatus {
    NEW,
    COMPLETED
}
