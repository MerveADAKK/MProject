package com.godoro.spring.orm.layer.business.dto;

import lombok.Data;

@Data
public class CategoryDto {
    private long categoryId;
    private String categoryName;
}
